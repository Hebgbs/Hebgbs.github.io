#!/bin/sh
chmod a+x ./wit
./wit cp . --DEST ../dwc-images/ --update --psel=data --http -vv
