#!/bin/sh
chmod a+x ./wit
./wit cp . --DEST ../wiimmfi-images/ --update --psel=data --wiimmfi -vv
