#!/bin/bash

function job()
{
    local MODE="$1"
    local SRCIMG="$2"
    local DESTIMG="./$MODE-images/${SRCIMG##*/}"
    local LANG="E F G I J K M Q S U"

    if [[ -s $DESTIMG ]]
    then
	printf "Image already exists => skip: %s\n" "$DESTIMG"
	return 0
    fi

    ##########################################################################
    # extract image

    sep="######################################"
    printf "\n#%s%s\n\n>>> Extract image: %s\n" "$sep" "$sep" "$SRCIMG"

    rm -rf "$workdir"
    wit extract -vv -1p "$SRCIMG" --links \
		--DEST "$workdir" --psel data || exit 1

    ##########################################################################
    ##########################################################################

    printf "\n>>> Patch messages for '$MODE'\n"

    for lang in $LANG
    do
	P=(--patch-bmg print=./bmg/$MODE-title.txt)
	F=./bmg/$MODE-$lang.txt
	[[ -f $F ]] && P=( "${P[@]}" --patch-bmg repl="$F" )

	wszst -q patch "$workdir/files/Scene/UI"/*_$lang.szs --ignore \
		"${P[@]}"
    done

    #-------------------------------------------------------------------------

    printf "\n>>> Patch server names for '$MODE'\n"

    if [[ $MODE = wiimmfi ]]
    then
	wstrt patch "$workdir/sys/main.dol" "$workdir/files/rel/StaticR.rel" \
		--wiimmfi --all-ranks
    else
	wstrt patch "$workdir/sys/main.dol" "$workdir/files/rel/StaticR.rel" \
		--https=http --all-ranks
    fi

    #-------------------------------------------------------------------------

    printf "\n>>> Create image '$MODE'\n"

    wit copy -vv --links "$workdir" --DEST "$DESTIMG"
}

