

		**************************************************
		**************************************************
		*****                                        *****
		*****      Wiimmfi and DWC patcher v1.0      *****
		*****   Special version for Mario Kart Wii   *****
		*****                                        *****
		**************************************************
		*****                                        *****
		*****      For Linux, Mac and Windows        *****
		*****               by Wiimm                 *****
		*****                                        *****
		**************************************************
		**************************************************



#######################
     Instructions:
#######################

1.) Copy all MKW images into this directory.

2.) Linux and Mac only: Execute: chmod a+x *.sh

3.) Start batch file 'patch-wiimmfi.bat' or 'patch-wiimmfi.sh'.

4.) All new patched images resist in the new sub-directory 'wiimmfi-images/'.
    Existing files will not overwritten.



For ALTWFC/DWC_NETWORK_SERVER_EMULATOR
--------------------------------------

3.) Start batch file 'patch-dwc.bat' or 'patch-dwc.sh'.
    with mouse in one way.

4.) All new patched images resist in the new sub-directory 'custom-images/'.
    Existing files will not overwritten.

5.) You must change your Name server settings.
    See https://github.com/polaris-/dwc_network_server_emulator/wiki




####################
     Anleitung:
####################

1.) Kopiere alle MKW-Images, die angepasst werden sollen,
    in dieses Verzeichnis.

2.) Nur Linux- und Mac-Nutzer f�hren das Kommando aus: chmod a+x *.sh

3.) Rufe 'patch-wiimmfi.bat' bzw. 'patch-wiimmfi.sh' auf.

4.) Alle neuen und gepatchten Images befinden sich im Unterverzeichnis
    'wiimmfi-images/'. Dabei werden keine Dateien �berschrieben und
    bereits bestehende Images werden nicht neu erstellt.



For ALTWFC/DWC_NETWORK_SERVER_EMULATOR
--------------------------------------

3.) Rufe 'patch-custom.bat' bzw. 'patch-custom.sh' auf.

4.) Alle neuen und gepatchten Images befinden sich im Unterverzeichnis
    'custom-images/'. Dabei werden keine Dateien �berschrieben und
    bereits bestehende Images werden nicht neu erstellt.

5.) Die Name-Server-Einstellungen der Wii m�ssen ge�ndert werden.
    Siehe hierzu: https://github.com/polaris-/dwc_network_server_emulator/wiki


