#!/bin/bash
. ./bin/setup.sh
printf "Remove $workdir\n"
rm -rf "$workdir"
