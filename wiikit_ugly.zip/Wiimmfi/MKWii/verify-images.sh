#!/bin/bash
. ./bin/setup.sh
wit verify . --verbose --verbose --ignore-fst
