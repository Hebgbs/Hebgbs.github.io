#!/bin/bash

. ./bin/setup.sh
. job.sh

wit img . -n RMC | while read src
do
    job custom "$src" || exit 1
done

exit 0
