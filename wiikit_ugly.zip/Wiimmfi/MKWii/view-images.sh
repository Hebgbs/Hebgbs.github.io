#!/bin/bash
. ./bin/setup.sh
wit filetype . --long --long --ignore-fst
