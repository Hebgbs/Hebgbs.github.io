You MUST first install the Qogir icon theme from AUR as follows.

$ -- In your terminal: --
sudo pacman -S qogir-icon-theme

Each icon is sized to the intended width as defined in the directory path they reside in. The theme comes in two varieties; a standard, upright logo and the same logo rotated clockwise 45 degrees. The upright, non-rotated images were made with the clockwise-rotated images for people who use weird things with the possibility for a circular icon mask like GNOME Pie, for instance — It won't look different aside from rotation. For people bored of the regular Manjaro logo with its squareness, making it a diamond may be a fun change of pace.

This theme functions by using Qogir-manjaro as a hier. This means I don't have to republish the theme in whole for users to enjoy this small change! Place in $HOME/.icons for yourself or /usr/share/themes (as super user) for other people.
